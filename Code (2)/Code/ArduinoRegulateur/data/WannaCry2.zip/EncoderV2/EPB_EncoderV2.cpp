#include "EPB_EncoderV2.h"

void EncoderOneIsr(void);
void EncoderTwoIsr(void);
volatile int32_t tickCount1;
volatile int32_t tickCount2;

uint8_t _pinA1, _pinB1, _pinA2, _pinB2;

EPB_Encoder::EPB_Encoder(uint8_t pinA, uint8_t pinB, uint8_t number) {
    if (number == 1)
    {
        _pinA1 = pinA;
        _pinB1 = pinB;
    }
    if (number == 2)
    {
        _pinA2 = pinA;
        _pinB2 = pinB;
    }
}

void EPB_Encoder::begin(uint8_t number) {
    if (number == 1)
    {
        pinMode(_pinA1, INPUT_PULLUP);
        pinMode(_pinB1, INPUT_PULLUP);
        delay(10);
        tickCount1 = 0;
        attachInterrupt(digitalPinToInterrupt(_pinA1), &EncoderOneIsr, CHANGE);
    }
    if (number == 2)
    {
        pinMode(_pinA2, INPUT_PULLUP);
        pinMode(_pinB2, INPUT_PULLUP);
        delay(10);
        tickCount2 = 0;
        attachInterrupt(digitalPinToInterrupt(_pinA2), &EncoderTwoIsr, CHANGE);
    }
}
/*
void EPB_Encoder::setPin(uint8_t pinA, uint8_t pinB) {
    _pinA = pinA;
    _pinB = pinB;
    pinMode(_pinA, INPUT_PULLUP);
    pinMode(_pinB, INPUT_PULLUP);
    delay(10);
    attachInterrupt(digitalPinToInterrupt(_pinA), &EncoderIsr, CHANGE);
}*/


int32_t EPB_Encoder::read(uint8_t number) {
  int32_t tmp;
  cli();
  if (number == 1)
  {
      tmp = tickCount1;
  }
  else
  {
      tmp = tickCount2;
  }
  sei();
  return(tmp);
}

void EncoderOneIsr(void) {
    uint8_t chA = digitalRead(_pinA1);
    uint8_t chB = digitalRead(_pinB1);

    if (chA == 0) {
        if (chB == 0) {
            tickCount1++;
        }
        else {
            tickCount1--;
        }
    }
    else {
        if (chB == 0) {
            tickCount1--;
        }
        else {
            tickCount1++;
        }
    }
}

void EncoderTwoIsr(void) {
    uint8_t chA = digitalRead(_pinA2);
    uint8_t chB = digitalRead(_pinB2);

    if (chA == 0) {
        if (chB == 0) {
            tickCount2++;
        }
        else {
            tickCount2--;
        }
    }
    else {
        if (chB == 0) {
            tickCount2--;
        }
        else {
            tickCount2++;
        }
    }
}
