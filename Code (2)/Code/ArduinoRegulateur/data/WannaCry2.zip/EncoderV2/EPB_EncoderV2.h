#ifndef EPB_ENCODERV2_H
#define EPB_ENCODERV2_H

#include <Arduino.h>

class EPB_Encoder {
    public:
        EPB_Encoder(uint8_t pinA, uint8_t pinB, uint8_t number);
        //void setPin(uint8_t pinA, uint8_t pinB);
        void begin(uint8_t number);
        int32_t read(uint8_t number);
};

#endif
