#include "EPB_EncoderV2.h"

void EncoderIsr(void);
volatile int32_t tickCount;
uint8_t _pinA, _pinB;


EPB_Encoder::EPB_Encoder(uint8_t pinA, uint8_t pinB) {
    _pinA = pinA;
    _pinB = pinB;
}

void EPB_Encoder::begin() {
    pinMode(_pinA, INPUT_PULLUP);
    pinMode(_pinB, INPUT_PULLUP);
    delay(10);
    tickCount = 0;
    attachInterrupt(digitalPinToInterrupt(_pinA), &EncoderIsr, CHANGE);
}

void EPB_Encoder::setPin(uint8_t pinA, uint8_t pinB) {
    _pinA = pinA;
    _pinB = pinB;
    pinMode(_pinA, INPUT_PULLUP);
    pinMode(_pinB, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(_pinA), &EncoderIsr, CHANGE);
}


int32_t EPB_Encoder::read() {
  int32_t tmp;
  
  cli();
  tmp = tickCount;
  sei();
  return(tmp);
}

void EncoderIsr(void) {
  uint8_t chA = digitalRead(_pinA);
  uint8_t chB = digitalRead(_pinB);

  if (chA == 0) {
    if (chB == 0) {
      tickCount++;
    } else {
      tickCount--;
    }
  } else {
    if (chB == 0) {
      tickCount--;
    } else {
      tickCount++;
    }
  }  
}
