#ifndef EPB_ENCODERV2_H
#define EPB_ENCODERV2_H

#include <Arduino.h>

class EPB_Encoder {
    public:
        EPB_Encoder(uint8_t pinA, uint8_t pinB);
        void setPin(uint8_t pinA, uint8_t pinB);
        void begin();
        int32_t read();
};

#endif
