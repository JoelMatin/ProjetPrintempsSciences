#ifndef EPB_ENCODER_H
#define EPB_ENCODER_H

#include <Arduino.h>

class EPB_encoder {
    public:
        EPB_encoder(uint8_t pinA, uint8_t pinB);
        void begin();
        int32_t read();
};

#endif
